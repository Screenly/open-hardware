# Screenly CM5 Player: Assembly Notes

| Item | Value |
| ---- | ----- |
| Part number | SRLY-ESP-000001 |
| Variant | eMMC |
| Bare PCB | SRLY-PCB-000001 (Screenly CM5 Player R0) |
| Programming | None: the assembly is delivered without firmware |

## Files

| File | Content |
| ---- | ------- |
| `SRLY-ESP-000001-assembly-top.pdf` | Assembly drawing, top side: fabrication and silkscreen layers; do-not-fit parts are crossed out |
| `SRLY-ESP-000001-bom.csv` | Bill of materials, one line per part number |
| `SRLY-ESP-000001-cpl.csv` | Pick-and-place file, CSV (Designator, Mid X, Mid Y, Rotation, Layer), SMD parts only |
| `SRLY-ESP-000001-hbom.cdx.json` | Hardware bill of materials (HBOM), CycloneDX 1.6 JSON |
| `SRLY-ESP-000001.pos` | Pick-and-place file, KiCad text format, SMD parts only |

Coordinates are in mm and match the Gerber files of the bare PCB. The solder paste (stencil) layers are in the bare PCB package.

## Assembly

| Item | Value |
| ---- | ----- |
| Sides | top |
| SMD placements | 172 |
| Through-hole parts | 8 |
| Part numbers (BOM lines) | 48 |

## Through-Hole Parts

Not in the pick-and-place files; solder by hand, selective or wave soldering:

C1, J5, J6, J10, J11, J15, SW1, SW2

## Do Not Fit

Footprints on the board that stay empty in the eMMC variant:

C20, C21, C22, C23, C24, C25, C26, C27, C28, C29, C50, C60, C61, C62, J7, J14, L3, R1, R21, R22, R23, R24, R25, R26, R62, R63, R64, U4, U11
