# Screenly CM5 Player: PCB Fabrication Notes

| Item | Value |
| ---- | ----- |
| Part number | SRLY-PCB-000001 |
| Design / revision | Screenly CM5 Player R0 |
| Source | KiCad 10.0.8, [github.com/Screenly/open-hardware](https://github.com/Screenly/open-hardware) |

## Files

Gerber X2 (RS-274X with attributes), metric, absolute coordinates.

| File | Content |
| ---- | ------- |
| `screenly-cm5-player-B_Cu.gbr` | L4, bottom copper |
| `screenly-cm5-player-B_Mask.gbr` | Solder mask, bottom |
| `screenly-cm5-player-B_Paste.gbr` | Solder paste (stencil), bottom |
| `screenly-cm5-player-B_Silkscreen.gbr` | Silkscreen, bottom |
| `screenly-cm5-player-Edge_Cuts.gbr` | Board outline |
| `screenly-cm5-player-F_Cu.gbr` | L1, top copper |
| `screenly-cm5-player-F_Fab.gbr` | Assembly drawing, for reference only. Do not fabricate. |
| `screenly-cm5-player-F_Mask.gbr` | Solder mask, top |
| `screenly-cm5-player-F_Paste.gbr` | Solder paste (stencil), top |
| `screenly-cm5-player-F_Silkscreen.gbr` | Silkscreen, top |
| `screenly-cm5-player-In1_Cu.gbr` | L2, inner copper (GND plane) |
| `screenly-cm5-player-In2_Cu.gbr` | L3, inner copper (signals and GND) |
| `screenly-cm5-player-NPTH.drl` | Non-plated holes (Excellon) |
| `screenly-cm5-player-PTH.drl` | Plated holes and plated slots (Excellon) |
| `screenly-cm5-player-job.gbrjob` | Gerber job file: layer order, stackup, finish, size |

## Board

| Item | Value |
| ---- | ----- |
| Layers | 4 |
| Size | 120 × 120 mm |
| Thickness | 1.6 mm |
| Outer / inner copper | 1 oz (35 µm) / 0.5 oz (15 µm) finished |
| Surface finish | ENIG |
| Solder mask | Purple, both sides |
| Silkscreen | White, both sides |
| Vias | Tented, not filled or plugged. |
| Plated slots | Yes: 0.6, 0.8, 0.9 mm wide |
| Castellated holes / edge plating / gold fingers | None |

## Stackup

| Layer | Material | Thickness |
| ----- | -------- | --------- |
| L1 top copper | Copper | 35 µm |
| Prepreg | FR4, Er 4.5 | 0.2104 mm |
| L2 inner copper | Copper | 15.2 µm |
| Core | FR4, Er 4.5 | 1.065 mm |
| L3 inner copper | Copper | 15.2 µm |
| Prepreg | FR4, Er 4.5 | 0.2104 mm |
| L4 bottom copper | Copper | 35 µm |

## Impedance Control

All controlled lines are differential pairs on L1 or L4, referenced to the adjacent GND plane (L2 or L3), with 0.2 mm spacing to the same-layer GND pour.

| Target | Trace width | Pair gap | Layers | Interfaces |
| ------ | ----------- | -------- | ------ | ---------- |
| 90 Ω differential | 0.1991 mm | 0.14 mm | L1, L4 | USB2, USB3, PCIE |
| 100 Ω differential | 0.1565 mm | 0.15 mm | L1 | HDMI, ETH |
